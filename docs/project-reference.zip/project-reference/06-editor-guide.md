# Editor Guide

## Safe Actions
- Edit text
- Update images
- Add Hot Topics
- Update stats values

---

## Do NOT Modify
- Container layout
- Spacing
- Colors
- Template structure
