# Component Library

## Hero – Pattern Background
Homepage main entry.

Editable:
- Headline
- Subheadline
- CTA buttons

---

## Dual Option Cards
Hot Topics vs Forum.

---

## Hot Topic Card
Used in curated lists.

---

## Category Grid
Forum category previews.

---

## Stats Panel
Forum metrics + CTA.
