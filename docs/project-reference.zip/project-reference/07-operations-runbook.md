# Operations Runbook

## Backup
 Frequently automated backups are required. Minimally monthly and increasing frequency as needed.

---

## Update Cycle
Plugins weekly.
Core monthly.

---

## Before Major Changes
Export templates.
Backup database.

---

## Rollback
Restore DB + revert Git commit.
