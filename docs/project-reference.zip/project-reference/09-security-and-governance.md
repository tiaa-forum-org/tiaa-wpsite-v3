# Security and Governance

## Plugin Policy
Minimal plugins preferred.

---

## Role Model
Editors: Content only.
Admins: Full access.

---

## Update Testing
Always test in staging first.

---

## Documentation Policy
Any architecture change requires doc update.
