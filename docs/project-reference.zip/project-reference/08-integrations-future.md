# Future Integrations

## Discourse Integration (Potential)

Possible features:
- Hot topic sync
- Forum stats API
- Category feed display

Implementation likely via site plugin or MU plugin.

---

## Automation Opportunities
- Scheduled topic sync
- Stats refresh cron job
